See https://github.com/atgp/factur-x
