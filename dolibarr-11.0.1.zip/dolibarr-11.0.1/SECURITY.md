# Security Policy

## Supported Versions

| Version  | Supported          |
| -------- | ------------------ |
| <= 8.0.* | :x: |
| >= 9.0.* | :white_check_mark: |

## Reporting a Vulnerability

To report a vulnerability, please send an email to security@dolibarr.org
In most cases, after fixing the security, we make an answer by email to say the issue has been fixed.
